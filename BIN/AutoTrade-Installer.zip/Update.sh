#!/usr/bin/bash
echo " Update Package..."
yum makecache
yum update fx_autotrade-system -y